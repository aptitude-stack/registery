# Invalid Postman Skill

Valid bundle paired with invalid metadata.
