# Postman Dependency Skill

Dependency bundle fixture for Bruno coverage.
