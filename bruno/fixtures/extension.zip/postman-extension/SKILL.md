# Postman Extension Skill

Extension bundle fixture for Bruno coverage.
