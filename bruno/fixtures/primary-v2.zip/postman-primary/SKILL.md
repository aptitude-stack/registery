# Postman Primary Skill v2

Bundle fixture for Bruno exact zip fetch coverage.
