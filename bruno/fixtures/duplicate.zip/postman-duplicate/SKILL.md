# Duplicate Seed Skill

Duplicate publish bundle fixture.
