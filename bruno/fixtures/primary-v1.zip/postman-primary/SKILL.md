# Postman Primary Skill v1

Bundle fixture for Bruno publish coverage.
